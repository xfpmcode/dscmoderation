// Generate Discord bot invite link
const clientId = process.env.DISCORD_CLIENT_ID;

if (!clientId) {
  console.error("DISCORD_CLIENT_ID environment variable is required");
  process.exit(1);
}

// Bot permissions needed for community management
const permissions = [
  "ViewChannels",           // 1024
  "SendMessages",           // 2048  
  "ManageMessages",         // 8192
  "EmbedLinks",            // 16384
  "ReadMessageHistory",     // 65536
  "UseSlashCommands",       // 2147483648
  "KickMembers",           // 2
  "BanMembers",            // 4
  "ModerateMembers",       // 1099511627776 (timeout members)
  "ManageRoles",           // 268435456
  "ManageChannels",        // 16
  "ManageGuild",           // 32
].join(",");

// Calculate permission value
const permissionValue = 
  1024 +           // View Channels
  2048 +           // Send Messages
  8192 +           // Manage Messages
  16384 +          // Embed Links
  65536 +          // Read Message History
  2147483648 +     // Use Slash Commands
  2 +              // Kick Members
  4 +              // Ban Members
  1099511627776 +  // Moderate Members (timeout)
  268435456 +      // Manage Roles
  16 +             // Manage Channels
  32;              // Manage Guild

// Direct bot invite link (should work without code grant issues)
const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=${permissionValue}&scope=bot`;

// Basic invite with minimal permissions to test
const basicInviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&permissions=2048&scope=bot`;

// Manual Discord Developer Portal method
const manualSteps = `
MANUAL METHOD (if links don't work):
1. Go to: https://discord.com/developers/applications
2. Select your application: ${clientId}
3. Go to "OAuth2" > "URL Generator"
4. Check "bot" scope
5. Select permissions you need
6. Copy the generated URL
`;

console.log("\n🤖 Discord Bot Invite Link Generated!");
console.log("═".repeat(60));
console.log(`\nBot Client ID: ${clientId}`);
console.log(`Permissions Value: ${permissionValue}`);
console.log("\n📋 Bot invite link (simplified):");
console.log("─".repeat(60));
console.log(inviteUrl);
console.log("─".repeat(60));
console.log("\n📋 Basic invite link (minimal permissions - test this if above fails):");
console.log("─".repeat(60));
console.log(basicInviteUrl);
console.log("─".repeat(60));
console.log(manualSteps);
console.log("\n✅ Permissions included:");
console.log("• View Channels & Send Messages");
console.log("• Manage Messages & Read History");
console.log("• Use Slash Commands");
console.log("• Kick & Ban Members");
console.log("• Timeout Members (Moderate Members)");
console.log("• Manage Roles & Channels");
console.log("• Manage Server");
console.log("\n🔗 To invite the bot:");
console.log("1. Copy the link above");
console.log("2. Paste it in your browser");
console.log("3. Select the Discord server");
console.log("4. Confirm the permissions");
console.log("\n⚠️  Note: You need 'Manage Server' permission to add bots!");