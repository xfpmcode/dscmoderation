import { db } from "../server/db";
import { serverConfigs, customCommands, moderationLogs } from "../shared/schema";

async function seedDemoData() {
  try {
    console.log("Seeding demo data...");

    // Create a demo server configuration
    const demoServerId = "1234567890123456789";
    
    await db.insert(serverConfigs).values({
      id: demoServerId,
      name: "Community Management Demo Server",
      welcomeChannelId: "1234567890123456790",
      welcomeMessage: "Welcome {user} to our amazing Discord community! We're glad to have you here. Check out our rules and have fun!",
      goodbyeMessage: "Goodbye {username}! Thanks for being part of our community.",
      autoRoleId: "1234567890123456791",
      moderationLogChannelId: "1234567890123456792",
      announcementChannelId: "1234567890123456793",
      ticketCategoryId: "1234567890123456794",
      moderatorRoleIds: ["1234567890123456795", "1234567890123456796"],
      adminRoleIds: ["1234567890123456797"],
      enableSpamProtection: true,
      maxMessagesPerMinute: 10,
    }).onConflictDoNothing();

    // Create demo custom commands
    await db.insert(customCommands).values([
      {
        serverId: demoServerId,
        name: "rules",
        description: "Display server rules",
        response: "📋 **Server Rules:**\n1. Be respectful to all members\n2. No spam or self-promotion\n3. Use appropriate channels\n4. Follow Discord ToS\n5. Have fun!",
        createdBy: "demo-admin",
      },
      {
        serverId: demoServerId,
        name: "help",
        description: "Show available commands",
        response: "🤖 **Available Commands:**\n• `!rules` - View server rules\n• `!help` - This message\n• `!support` - Get help from moderators\n\nFor moderation commands, use slash commands like `/kick`, `/ban`, `/warn`",
        createdBy: "demo-admin",
      },
      {
        serverId: demoServerId,
        name: "support",
        description: "Get support information",
        response: "🎫 Need help? Please create a support ticket by clicking the button below or contact a moderator directly!",
        createdBy: "demo-admin",
      },
    ]).onConflictDoNothing();

    // Create demo moderation logs with case numbers
    await db.insert(moderationLogs).values([
      {
        caseNumber: 1,
        serverId: demoServerId,
        targetUserId: "9876543210987654321",
        moderatorUserId: "1111111111111111111",
        action: "warn",
        reason: "Inappropriate language in general chat",
      },
      {
        caseNumber: 2,
        serverId: demoServerId,
        targetUserId: "8765432109876543210",
        moderatorUserId: "1111111111111111111",
        action: "kick",
        reason: "Repeated spam after warnings",
      },
      {
        caseNumber: 3,
        serverId: demoServerId,
        targetUserId: "7654321098765432109",
        moderatorUserId: "2222222222222222222",
        action: "ban",
        reason: "Harassment and toxic behavior",
        duration: null,
      },
      {
        caseNumber: 4,
        serverId: demoServerId,
        targetUserId: "6543210987654321098",
        moderatorUserId: "1111111111111111111",
        action: "timeout",
        reason: "Automatic spam protection",
        duration: 5,
      },
    ]).onConflictDoNothing();

    console.log("✅ Demo data seeded successfully!");
    console.log(`Demo server ID: ${demoServerId}`);
    console.log("You can now test the dashboard with this server ID");
    
  } catch (error) {
    console.error("❌ Error seeding demo data:", error);
  }
}

seedDemoData().then(() => process.exit(0));