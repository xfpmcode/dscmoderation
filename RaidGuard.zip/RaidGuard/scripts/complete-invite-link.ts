// Complete the Discord invite link with proper parameters
const baseUrl = "https://discord.com/oauth2/authorize?client_id=1400793896606498906";

// Essential bot permissions for community management
const permissions = 
  2048 +           // Send Messages
  8192 +           // Manage Messages  
  16384 +          // Embed Links
  65536 +          // Read Message History
  2 +              // Kick Members
  4 +              // Ban Members
  1099511627776 +  // Moderate Members (timeout)
  268435456 +      // Manage Roles
  16 +             // Manage Channels
  1024;            // View Channels

const completeUrl = `${baseUrl}&permissions=${permissions}&scope=bot`;

console.log("🔗 Complete Discord Bot Invite Link:");
console.log("=" .repeat(70));
console.log(completeUrl);
console.log("=" .repeat(70));
console.log("\n✅ This link includes:");
console.log("• Basic bot permissions");
console.log("• Moderation capabilities");
console.log("• Message management");
console.log("• Channel access");
console.log("\n📋 Copy the link above and paste it in your browser to invite the bot!");