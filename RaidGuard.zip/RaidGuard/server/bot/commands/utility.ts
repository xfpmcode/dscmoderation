import { SlashCommandBuilder, ChatInputCommandInteraction, PermissionFlagsBits } from "discord.js";
import { storage } from "../../storage";
import { createInfoEmbed, createModerationEmbed } from "../utils/embedBuilder";
import { hasAdminPermission } from "../utils/permissions";

export const serverInfoCommand = {
  data: new SlashCommandBuilder()
    .setName("serverinfo")
    .setDescription("Display server information"),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const guild = interaction.guild;
    const memberCount = guild.memberCount;
    const boostLevel = guild.premiumTier;
    const boostCount = guild.premiumSubscriptionCount;
    const createdAt = guild.createdAt.toLocaleDateString();

    const embed = createInfoEmbed("Server Information", [
      { name: "Server Name", value: guild.name, inline: true },
      { name: "Member Count", value: memberCount.toString(), inline: true },
      { name: "Created Date", value: createdAt, inline: true },
      { name: "Boost Level", value: boostLevel.toString(), inline: true },
      { name: "Boost Count", value: boostCount?.toString() || "0", inline: true },
      { name: "Server ID", value: guild.id, inline: true },
    ]);

    if (guild.iconURL()) {
      embed.setThumbnail(guild.iconURL()!);
    }

    await interaction.reply({ embeds: [embed] });
  },
};

export const caseCommand = {
  data: new SlashCommandBuilder()
    .setName("case")
    .setDescription("Look up a moderation case")
    .addIntegerOption(option =>
      option.setName("number")
        .setDescription("Case number to look up")
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const caseNumber = interaction.options.getInteger("number", true);

    try {
      const logs = await storage.getModerationLogs(interaction.guild.id, 100);
      const caseLog = logs.find(log => log.caseNumber === caseNumber);

      if (!caseLog) {
        return interaction.reply({ content: `Case #${caseNumber} not found.`, ephemeral: true });
      }

      // Get user info
      const targetUser = await interaction.client.users.fetch(caseLog.targetUserId).catch(() => null);
      const moderator = await interaction.client.users.fetch(caseLog.moderatorUserId).catch(() => null);

      const embed = createModerationEmbed(`Case #${caseNumber} - ${caseLog.action.toUpperCase()}`, {
        target: targetUser || undefined,
        moderator: moderator || undefined,
        reason: caseLog.reason || "No reason provided",
        caseNumber: caseLog.caseNumber,
        extra: caseLog.duration ? `Duration: ${caseLog.duration} minutes` : undefined,
        timestamp: true,
      });

      embed.setFooter({ text: `Case created on ${new Date(caseLog.createdAt).toLocaleString()}` });

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error fetching case:", error);
      await interaction.reply({ content: "Failed to fetch case information.", ephemeral: true });
    }
  },
};

export const pingCommand = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check bot latency and response time"),

  async execute(interaction: ChatInputCommandInteraction) {
    const sent = await interaction.reply({ content: "Pinging...", fetchReply: true });
    const timeDiff = sent.createdTimestamp - interaction.createdTimestamp;
    
    const embed = createInfoEmbed("🏓 Pong!", [
      { name: "Roundtrip Latency", value: `${timeDiff}ms`, inline: true },
      { name: "WebSocket Heartbeat", value: `${Math.round(interaction.client.ws.ping)}ms`, inline: true },
      { name: "Bot Status", value: "Online ✅", inline: true },
    ]);

    await interaction.editReply({ content: "", embeds: [embed] });
  },
};

export const userInfoCommand = {
  data: new SlashCommandBuilder()
    .setName("userinfo")
    .setDescription("Display user information")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to get information about")
        .setRequired(false)),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user") || interaction.user;
    
    try {
      const member = await interaction.guild.members.fetch(targetUser.id);
      const joinedAt = member.joinedAt?.toLocaleDateString() || "Unknown";
      const createdAt = targetUser.createdAt.toLocaleDateString();
      const roles = member.roles.cache
        .filter(role => role.name !== "@everyone")
        .map(role => role.name)
        .slice(0, 10)
        .join(", ") || "No roles";

      const embed = createInfoEmbed("User Information", [
        { name: "Username", value: targetUser.username, inline: true },
        { name: "Display Name", value: member.displayName, inline: true },
        { name: "User ID", value: targetUser.id, inline: true },
        { name: "Joined Server", value: joinedAt, inline: true },
        { name: "Account Created", value: createdAt, inline: true },
        { name: "Roles", value: roles, inline: false },
      ]);

      if (targetUser.avatarURL()) {
        embed.setThumbnail(targetUser.avatarURL()!);
      }

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error fetching user info:", error);
      await interaction.reply({ content: "Failed to fetch user information.", ephemeral: true });
    }
  },
};

export const announceCommand = {
  data: new SlashCommandBuilder()
    .setName("announce")
    .setDescription("Send an announcement message")
    .addStringOption(option =>
      option.setName("message")
        .setDescription("The announcement message")
        .setRequired(true))
    .addChannelOption(option =>
      option.setName("channel")
        .setDescription("The channel to send the announcement to")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.member) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const hasPermission = await hasAdminPermission(interaction.member, interaction.guild.id);
    if (!hasPermission) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const message = interaction.options.getString("message", true);
    const targetChannel = interaction.options.getChannel("channel") || interaction.channel;

    if (!targetChannel?.isTextBased()) {
      return interaction.reply({ content: "Invalid channel specified.", ephemeral: true });
    }

    try {
      const embed = createModerationEmbed("📢 Announcement", {
        moderator: interaction.user,
        reason: message,
        timestamp: true,
      });

      await targetChannel.send({ embeds: [embed] });
      await interaction.reply({ content: "Announcement sent successfully!", ephemeral: true });
    } catch (error) {
      console.error("Error sending announcement:", error);
      await interaction.reply({ content: "Failed to send announcement.", ephemeral: true });
    }
  },
};

export const customCommand = {
  data: new SlashCommandBuilder()
    .setName("custom")
    .setDescription("Execute a custom command")
    .addStringOption(option =>
      option.setName("command")
        .setDescription("The custom command to execute")
        .setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const commandName = interaction.options.getString("command", true);

    try {
      const customCmd = await storage.getCustomCommand(interaction.guild.id, commandName);
      
      if (!customCmd) {
        return interaction.reply({ content: "Custom command not found.", ephemeral: true });
      }

      await interaction.reply({ content: customCmd.response });
    } catch (error) {
      console.error("Error executing custom command:", error);
      await interaction.reply({ content: "Failed to execute custom command.", ephemeral: true });
    }
  },
};
