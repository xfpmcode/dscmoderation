import { SlashCommandBuilder, PermissionFlagsBits, ChatInputCommandInteraction, GuildMember } from "discord.js";
import { storage } from "../../storage";
import { createModerationEmbed } from "../utils/embedBuilder";
import { hasModeratorPermission } from "../utils/permissions";

export const kickCommand = {
  data: new SlashCommandBuilder()
    .setName("kick")
    .setDescription("Kick a member from the server")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to kick")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("reason")
        .setDescription("Reason for the kick")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.member) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const hasPermission = await hasModeratorPermission(interaction.member as GuildMember, interaction.guild.id);
    if (!hasPermission) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason") || "No reason provided";

    try {
      const member = await interaction.guild.members.fetch(targetUser.id);
      
      if (!member.kickable) {
        return interaction.reply({ content: "I cannot kick this user.", ephemeral: true });
      }

      await member.kick(reason);

      // Log the action and get case number
      const moderationLog = await storage.createModerationLog({
        serverId: interaction.guild.id,
        targetUserId: targetUser.id,
        moderatorUserId: interaction.user.id,
        action: "kick",
        reason,
      });

      const embed = createModerationEmbed("Kick", {
        target: targetUser,
        moderator: interaction.user,
        reason,
        caseNumber: moderationLog.caseNumber,
      });

      await interaction.reply({ embeds: [embed] });

      // Send to moderation log channel if configured
      const config = await storage.getServerConfig(interaction.guild.id);
      if (config?.moderationLogChannelId) {
        const logChannel = interaction.guild.channels.cache.get(config.moderationLogChannelId);
        if (logChannel?.isTextBased()) {
          await logChannel.send({ embeds: [embed] });
        }
      }
    } catch (error) {
      console.error("Error kicking user:", error);
      await interaction.reply({ content: "Failed to kick the user.", ephemeral: true });
    }
  },
};

export const banCommand = {
  data: new SlashCommandBuilder()
    .setName("ban")
    .setDescription("Ban a member from the server")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to ban")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("reason")
        .setDescription("Reason for the ban")
        .setRequired(false))
    .addIntegerOption(option =>
      option.setName("delete_days")
        .setDescription("Number of days of messages to delete (0-7)")
        .setMinValue(0)
        .setMaxValue(7)
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.member) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const hasPermission = await hasModeratorPermission(interaction.member as GuildMember, interaction.guild.id);
    if (!hasPermission) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason") || "No reason provided";
    const deleteDays = interaction.options.getInteger("delete_days") || 0;

    try {
      await interaction.guild.members.ban(targetUser, {
        reason,
        deleteMessageDays: deleteDays,
      });

      // Log the action
      await storage.createModerationLog({
        serverId: interaction.guild.id,
        targetUserId: targetUser.id,
        moderatorUserId: interaction.user.id,
        action: "ban",
        reason,
      });

      const embed = createModerationEmbed("Ban", {
        target: targetUser,
        moderator: interaction.user,
        reason,
        extra: deleteDays > 0 ? `Deleted ${deleteDays} days of messages` : undefined,
      });

      await interaction.reply({ embeds: [embed] });

      // Send to moderation log channel if configured
      const config = await storage.getServerConfig(interaction.guild.id);
      if (config?.moderationLogChannelId) {
        const logChannel = interaction.guild.channels.cache.get(config.moderationLogChannelId);
        if (logChannel?.isTextBased()) {
          await logChannel.send({ embeds: [embed] });
        }
      }
    } catch (error) {
      console.error("Error banning user:", error);
      await interaction.reply({ content: "Failed to ban the user.", ephemeral: true });
    }
  },
};

export const warnCommand = {
  data: new SlashCommandBuilder()
    .setName("warn")
    .setDescription("Warn a member")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to warn")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("reason")
        .setDescription("Reason for the warning")
        .setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.member) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const hasPermission = await hasModeratorPermission(interaction.member as GuildMember, interaction.guild.id);
    if (!hasPermission) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user", true);
    const reason = interaction.options.getString("reason", true);

    try {
      // Create warning record
      await storage.createUserWarning({
        serverId: interaction.guild.id,
        userId: targetUser.id,
        moderatorId: interaction.user.id,
        reason,
      });

      // Log the action
      await storage.createModerationLog({
        serverId: interaction.guild.id,
        targetUserId: targetUser.id,
        moderatorUserId: interaction.user.id,
        action: "warn",
        reason,
      });

      // Get total warnings for this user
      const warnings = await storage.getUserWarnings(interaction.guild.id, targetUser.id);

      const embed = createModerationEmbed("Warning", {
        target: targetUser,
        moderator: interaction.user,
        reason,
        extra: `Total warnings: ${warnings.length}`,
      });

      await interaction.reply({ embeds: [embed] });

      // Send to moderation log channel if configured
      const config = await storage.getServerConfig(interaction.guild.id);
      if (config?.moderationLogChannelId) {
        const logChannel = interaction.guild.channels.cache.get(config.moderationLogChannelId);
        if (logChannel?.isTextBased()) {
          await logChannel.send({ embeds: [embed] });
        }
      }

      // Try to DM the user about the warning
      try {
        const dmEmbed = createModerationEmbed("Warning Received", {
          target: targetUser,
          moderator: interaction.user,
          reason,
          server: interaction.guild.name,
        });
        await targetUser.send({ embeds: [dmEmbed] });
      } catch (error) {
        // User has DMs disabled, that's okay
      }
    } catch (error) {
      console.error("Error warning user:", error);
      await interaction.reply({ content: "Failed to warn the user.", ephemeral: true });
    }
  },
};

export const warningsCommand = {
  data: new SlashCommandBuilder()
    .setName("warnings")
    .setDescription("View warnings for a user")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to check warnings for")
        .setRequired(true)),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.member) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const hasPermission = await hasModeratorPermission(interaction.member as GuildMember, interaction.guild.id);
    if (!hasPermission) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user", true);

    try {
      const warnings = await storage.getUserWarnings(interaction.guild.id, targetUser.id);

      if (warnings.length === 0) {
        return interaction.reply({ content: `${targetUser.username} has no warnings.`, ephemeral: true });
      }

      const embed = createModerationEmbed("User Warnings", {
        target: targetUser,
        extra: `Total warnings: ${warnings.length}`,
        warnings: warnings.slice(0, 10), // Show last 10 warnings
      });

      await interaction.reply({ embeds: [embed], ephemeral: true });
    } catch (error) {
      console.error("Error fetching warnings:", error);
      await interaction.reply({ content: "Failed to fetch user warnings.", ephemeral: true });
    }
  },
};
