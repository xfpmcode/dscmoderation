import { SlashCommandBuilder, PermissionFlagsBits, ChatInputCommandInteraction } from "discord.js";
import { createInfoEmbed } from "../utils/embedBuilder";

export const pingCommand = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check bot latency and response time"),

  async execute(interaction: ChatInputCommandInteraction) {
    const sent = await interaction.reply({ content: "Pinging...", fetchReply: true });
    const timeDiff = sent.createdTimestamp - interaction.createdTimestamp;
    
    const embed = createInfoEmbed("🏓 Pong!", [
      { name: "Roundtrip Latency", value: `${timeDiff}ms`, inline: true },
      { name: "WebSocket Heartbeat", value: `${Math.round(interaction.client.ws.ping)}ms`, inline: true },
      { name: "Bot Status", value: "Online ✅", inline: true },
    ]);

    await interaction.editReply({ content: "", embeds: [embed] });
  },
};

export const cleanCommand = {
  data: new SlashCommandBuilder()
    .setName("clean")
    .setDescription("Delete a specified number of messages")
    .addIntegerOption(option =>
      option.setName("amount")
        .setDescription("Number of messages to delete (1-100)")
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(100))
    .addUserOption(option =>
      option.setName("user")
        .setDescription("Only delete messages from this user")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.channel?.isTextBased()) {
      return interaction.reply({ content: "This command can only be used in a text channel.", ephemeral: true });
    }

    const amount = interaction.options.getInteger("amount", true);
    const targetUser = interaction.options.getUser("user");

    try {
      const messages = await interaction.channel.messages.fetch({ limit: amount + 1 });
      
      let messagesToDelete = Array.from(messages.values()).slice(1);
      
      if (targetUser) {
        messagesToDelete = messagesToDelete.filter(msg => msg.author.id === targetUser.id);
      }

      const deletedCount = messagesToDelete.length;
      
      if (deletedCount === 0) {
        return interaction.reply({ content: "No messages found to delete.", ephemeral: true });
      }

      const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
      const recentMessages = messagesToDelete.filter(msg => msg.createdTimestamp > twoWeeksAgo);

      if (recentMessages.length > 0) {
        await interaction.channel.bulkDelete(recentMessages);
      }

      const embed = createInfoEmbed("🧹 Messages Cleaned", [
        { name: "Messages Deleted", value: deletedCount.toString(), inline: true },
        { name: "Target User", value: targetUser ? targetUser.username : "All users", inline: true },
        { name: "Channel", value: `#${interaction.channel.name}`, inline: true },
      ]);

      await interaction.reply({ embeds: [embed], ephemeral: true });

    } catch (error) {
      console.error("Error cleaning messages:", error);
      await interaction.reply({ content: "Failed to clean messages.", ephemeral: true });
    }
  },
};

export const uptimeCommand = {
  data: new SlashCommandBuilder()
    .setName("uptime")
    .setDescription("Check how long the bot has been running"),

  async execute(interaction: ChatInputCommandInteraction) {
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);

    const uptimeString = `${days}d ${hours}h ${minutes}m ${seconds}s`;
    
    const embed = createInfoEmbed("⏱️ Bot Uptime", [
      { name: "Current Uptime", value: uptimeString, inline: true },
      { name: "Server Count", value: interaction.client.guilds.cache.size.toString(), inline: true },
      { name: "Memory Usage", value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
    ]);

    await interaction.reply({ embeds: [embed] });
  },
};

export const slowmodeCommand = {
  data: new SlashCommandBuilder()
    .setName("slowmode")
    .setDescription("Set slowmode delay for the channel")
    .addIntegerOption(option =>
      option.setName("seconds")
        .setDescription("Slowmode delay in seconds (0-21600)")
        .setRequired(true)
        .setMinValue(0)
        .setMaxValue(21600))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild || !interaction.channel?.isTextBased()) {
      return interaction.reply({ content: "This command can only be used in a text channel.", ephemeral: true });
    }

    const seconds = interaction.options.getInteger("seconds", true);

    try {
      await interaction.channel.setRateLimitPerUser(seconds);
      
      const embed = createInfoEmbed("⏱️ Slowmode Updated", [
        { name: "Channel", value: `#${interaction.channel.name}`, inline: true },
        { name: "Delay", value: seconds === 0 ? "Disabled" : `${seconds} seconds`, inline: true },
        { name: "Set by", value: interaction.user.username, inline: true },
      ]);

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error("Error setting slowmode:", error);
      await interaction.reply({ content: "Failed to set slowmode.", ephemeral: true });
    }
  },
};

export const dmCommand = {
  data: new SlashCommandBuilder()
    .setName("dm")
    .setDescription("Send direct messages to a user (with spam option)")
    .addUserOption(option =>
      option.setName("user")
        .setDescription("The user to send DMs to")
        .setRequired(true))
    .addStringOption(option =>
      option.setName("message")
        .setDescription("The message to send")
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName("count")
        .setDescription("Number of times to send the message (1-20)")
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(20))
    .addIntegerOption(option =>
      option.setName("delay")
        .setDescription("Delay between messages in seconds (0-10)")
        .setRequired(false)
        .setMinValue(0)
        .setMaxValue(10))
    .addBooleanOption(option =>
      option.setName("anonymous")
        .setDescription("Send the message anonymously (default: false)")
        .setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction: ChatInputCommandInteraction) {
    if (!interaction.guild) {
      return interaction.reply({ content: "This command can only be used in a server.", ephemeral: true });
    }

    const targetUser = interaction.options.getUser("user", true);
    const message = interaction.options.getString("message", true);
    const count = interaction.options.getInteger("count") || 1;
    const delay = interaction.options.getInteger("delay") || 0;
    const anonymous = interaction.options.getBoolean("anonymous") || false;

    // Prevent DMing bots
    if (targetUser.bot) {
      return interaction.reply({ content: "Cannot send DMs to bots.", ephemeral: true });
    }

    // Prevent self-DM
    if (targetUser.id === interaction.user.id) {
      return interaction.reply({ content: "You cannot DM yourself.", ephemeral: true });
    }

    try {
      // Create the DM embed
      const dmEmbed = createInfoEmbed(
        anonymous ? "📩 Anonymous Message" : "📩 Server Message",
        [
          { 
            name: "From", 
            value: anonymous ? `Server: ${interaction.guild.name}` : `${interaction.user.username} from ${interaction.guild.name}`, 
            inline: false 
          },
          { name: "Message", value: message, inline: false },
        ]
      );

      if (!anonymous) {
        dmEmbed.setFooter({ 
          text: `Sent by ${interaction.user.username} (${interaction.user.id})`,
          iconURL: interaction.user.avatarURL() || undefined
        });
      }

      // Send initial response
      const confirmEmbed = createInfoEmbed("📤 Sending DMs...", [
        { name: "Recipient", value: targetUser.username, inline: true },
        { name: "Count", value: count.toString(), inline: true },
        { name: "Delay", value: `${delay}s`, inline: true },
        { name: "Anonymous", value: anonymous ? "Yes" : "No", inline: true },
      ]);

      await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });

      let successCount = 0;
      let failCount = 0;

      // Send multiple DMs
      for (let i = 0; i < count; i++) {
        try {
          // Add message number if sending multiple
          const finalMessage = count > 1 ? `${message} (${i + 1}/${count})` : message;
          
          const dmEmbed = createInfoEmbed(
            anonymous ? "📩 Anonymous Message" : "📩 Server Message",
            [
              { 
                name: "From", 
                value: anonymous ? `Server: ${interaction.guild.name}` : `${interaction.user.username} from ${interaction.guild.name}`, 
                inline: false 
              },
              { name: "Message", value: finalMessage, inline: false },
            ]
          );

          if (!anonymous) {
            dmEmbed.setFooter({ 
              text: `Sent by ${interaction.user.username} (${interaction.user.id})`,
              iconURL: interaction.user.avatarURL() || undefined
            });
          }

          await targetUser.send({ embeds: [dmEmbed] });
          successCount++;

          // Add delay between messages (except for the last one)
          if (i < count - 1 && delay > 0) {
            await new Promise(resolve => setTimeout(resolve, delay * 1000));
          }

        } catch (error) {
          console.error(`Error sending DM ${i + 1}:`, error);
          failCount++;
        }
      }

      // Log the action
      await storage.createModerationLog({
        serverId: interaction.guild.id,
        targetUserId: targetUser.id,
        moderatorUserId: interaction.user.id,
        action: "dm",
        reason: `DM spam: "${message}" (${successCount}/${count} sent) ${anonymous ? "(anonymous)" : ""}`,
      });

      // Update with final results
      const finalEmbed = createInfoEmbed("✅ DM Spam Complete", [
        { name: "Recipient", value: targetUser.username, inline: true },
        { name: "Successful", value: successCount.toString(), inline: true },
        { name: "Failed", value: failCount.toString(), inline: true },
        { name: "Total Attempted", value: count.toString(), inline: true },
        { name: "Message Preview", value: message.length > 100 ? message.substring(0, 100) + "..." : message, inline: false },
      ]);

      await interaction.editReply({ embeds: [finalEmbed] });

    } catch (error) {
      console.error("Error sending DM:", error);
      
      let errorMessage = "Failed to send DM.";
      if (error.code === 50007) {
        errorMessage = "Cannot send DM to this user. They may have DMs disabled or have blocked the bot.";
      }
      
      await interaction.reply({ content: errorMessage, ephemeral: true });
    }
  },
};