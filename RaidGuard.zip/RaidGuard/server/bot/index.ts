import { Client, GatewayIntentBits, Collection, Events } from "discord.js";
import { setupMemberEvents } from "./events/memberEvents";
import { setupMessageEvents } from "./events/messageEvents";
import { setupTicketHandler } from "./handlers/ticketHandler";

// Create Discord client
export const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
  ],
});

// Initialize commands collection
bot.commands = new Collection();

// Bot ready event
bot.once(Events.ClientReady, (readyClient) => {
  console.log(`Discord bot is ready! Logged in as ${readyClient.user.tag}`);
  console.log(`Bot is in ${readyClient.guilds.cache.size} servers`);
});

// Error handling
bot.on(Events.Error, (error) => {
  console.error("Discord bot error:", error);
});

bot.on(Events.Warn, (warning) => {
  console.warn("Discord bot warning:", warning);
});

// Initialize bot
export async function initializeBot() {
  try {
    // Prefix commands are handled in messageEvents
    
    // Setup event handlers
    setupMemberEvents(bot);
    setupMessageEvents(bot);
    setupTicketHandler(bot);
    
    // Login to Discord
    const token = process.env.DISCORD_BOT_TOKEN;
    if (!token) {
      throw new Error("DISCORD_BOT_TOKEN environment variable is required");
    }
    
    await bot.login(token);
    console.log("Discord bot initialized successfully");
  } catch (error) {
    console.error("Failed to initialize Discord bot:", error);
    throw error;
  }
}

// Graceful shutdown
process.on("SIGINT", () => {
  console.log("Shutting down Discord bot...");
  bot.destroy();
  process.exit(0);
});

process.on("SIGTERM", () => {
  console.log("Shutting down Discord bot...");
  bot.destroy();
  process.exit(0);
});

// Export for use in other modules
export default bot;
