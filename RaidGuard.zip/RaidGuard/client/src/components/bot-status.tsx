import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Activity, Wifi, WifiOff, RefreshCw } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";

interface BotStatusProps {
  status?: {
    online: boolean;
    serverCount: number;
    uptime: number;
  };
}

export default function BotStatus({ status }: BotStatusProps) {
  const queryClient = useQueryClient();

  const refreshStatus = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/bot/status"] });
  };

  const formatUptime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h ${minutes % 60}m`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-lg">Bot Status</CardTitle>
          </div>
          <Button variant="outline" size="sm" onClick={refreshStatus}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
        <CardDescription>
          Real-time status of your Discord moderation bot
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center space-x-3">
            {status?.online ? (
              <Wifi className="h-8 w-8 text-green-500" />
            ) : (
              <WifiOff className="h-8 w-8 text-red-500" />
            )}
            <div>
              <p className="text-sm font-medium text-muted-foreground">Status</p>
              <Badge 
                variant={status?.online ? "default" : "destructive"}
                className={status?.online ? "bg-green-500 hover:bg-green-600" : ""}
              >
                {status?.online ? "Online" : "Offline"}
              </Badge>
            </div>
          </div>

          <div>
            <p className="text-sm font-medium text-muted-foreground">Servers</p>
            <p className="text-2xl font-bold">{status?.serverCount || 0}</p>
          </div>

          <div>
            <p className="text-sm font-medium text-muted-foreground">Uptime</p>
            <p className="text-lg font-semibold">
              {status?.uptime ? formatUptime(status.uptime) : "Unknown"}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}