import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Server, Users, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";

interface ServerSelectorProps {
  onServerSelect: (serverId: string) => void;
}

export default function ServerSelector({ onServerSelect }: ServerSelectorProps) {
  const [selectedServer, setSelectedServer] = useState<string>("");

  // For demo purposes, we'll use a demo server ID
  const demoServer = {
    id: "1234567890123456789",
    name: "Demo Server",
    memberCount: 1250,
    online: true
  };

  const handleServerChange = (serverId: string) => {
    setSelectedServer(serverId);
    onServerSelect(serverId);
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Server className="h-5 w-5 text-blue-600" />
            <CardTitle className="text-lg">Server Selection</CardTitle>
          </div>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Add Bot to Server
          </Button>
        </div>
        <CardDescription>
          Choose a server to manage and view its moderation dashboard
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Select value={selectedServer} onValueChange={handleServerChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select a server to manage" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={demoServer.id}>
                <div className="flex items-center space-x-2">
                  <span>{demoServer.name}</span>
                  <Badge variant="secondary" className="ml-2">
                    <Users className="h-3 w-3 mr-1" />
                    {demoServer.memberCount}
                  </Badge>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          {selectedServer && (
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Server className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-blue-900 dark:text-blue-100">
                    {demoServer.name}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary">
                    <Users className="h-3 w-3 mr-1" />
                    {demoServer.memberCount} members
                  </Badge>
                  <Badge variant="default" className="bg-green-500">
                    Active
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                Bot is active and ready to moderate this server
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}