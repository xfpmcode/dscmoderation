import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MessageSquare, Shield, AlertTriangle, Home } from "lucide-react";
import { Link } from "wouter";
import ServerSelector from "@/components/server-selector";

export default function Logs() {
  const [selectedServerId, setSelectedServerId] = useState<string>("");
  const [logLimit, setLogLimit] = useState<number>(50);

  const { data: moderationLogs, isLoading: modLogsLoading } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "logs/moderation", { limit: logLimit }],
    enabled: !!selectedServerId,
  });

  const { data: messageLogs, isLoading: msgLogsLoading } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "logs/messages", { limit: logLimit }],
    enabled: !!selectedServerId,
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <MessageSquare className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Bot Logs
              </h1>
            </div>
            <nav className="flex space-x-4">
              <Link href="/">
                <Button variant="ghost">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
              <Link href="/logs">
                <Button variant="ghost" className="text-blue-600">
                  Logs
                </Button>
              </Link>
              <Link href="/settings">
                <Button variant="ghost">Settings</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Server Selector */}
        <div className="mb-8">
          <ServerSelector onServerSelect={setSelectedServerId} />
        </div>

        {/* Controls */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
              Log Limit:
            </label>
            <Select value={logLimit.toString()} onValueChange={(value) => setLogLimit(parseInt(value))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
                <SelectItem value="200">200</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedServerId ? (
          <Tabs defaultValue="moderation" className="space-y-4">
            <TabsList>
              <TabsTrigger value="moderation">
                <Shield className="h-4 w-4 mr-2" />
                Moderation Logs
              </TabsTrigger>
              <TabsTrigger value="messages">
                <MessageSquare className="h-4 w-4 mr-2" />
                Message Logs
              </TabsTrigger>
            </TabsList>

            <TabsContent value="moderation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Moderation Actions</CardTitle>
                  <CardDescription>
                    History of moderation actions taken by bot and moderators
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {modLogsLoading ? (
                    <div className="space-y-3">
                      {[...Array(10)].map((_, i) => (
                        <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : moderationLogs && moderationLogs.length > 0 ? (
                    <div className="space-y-3">
                      {moderationLogs.map((log: any) => (
                        <div key={log.id} className="border rounded-lg p-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              {log.caseNumber && (
                                <Badge variant="outline" className="text-xs">
                                  Case #{log.caseNumber}
                                </Badge>
                              )}
                              <Badge variant={
                                log.action === "ban" ? "destructive" :
                                log.action === "kick" ? "secondary" :
                                log.action === "warn" ? "outline" :
                                log.action === "timeout" ? "default" : "default"
                              }>
                                {log.action.toUpperCase()}
                              </Badge>
                              <span className="font-medium">
                                Target: {log.targetUserId}
                              </span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {new Date(log.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="font-medium">Moderator:</span> {log.moderatorUserId}
                            </div>
                            <div>
                              <span className="font-medium">Reason:</span> {log.reason || "No reason provided"}
                            </div>
                            {log.duration && (
                              <div>
                                <span className="font-medium">Duration:</span> {log.duration} minutes
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No moderation logs found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="messages" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Message Events</CardTitle>
                  <CardDescription>
                    History of deleted and edited messages
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {msgLogsLoading ? (
                    <div className="space-y-3">
                      {[...Array(10)].map((_, i) => (
                        <div key={i} className="h-20 bg-gray-200 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : messageLogs && messageLogs.length > 0 ? (
                    <div className="space-y-3">
                      {messageLogs.map((log: any) => (
                        <div key={log.id} className="border rounded-lg p-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <Badge variant={log.action === "deleted" ? "destructive" : "secondary"}>
                                {log.action.toUpperCase()}
                              </Badge>
                              <span className="font-medium">
                                User: {log.userId}
                              </span>
                              <span className="text-sm text-muted-foreground">
                                Channel: #{log.channelId}
                              </span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {new Date(log.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                            <div className="text-sm">
                              <span className="font-medium">Content:</span>
                            </div>
                            <div className="text-sm text-muted-foreground mt-1 font-mono">
                              {log.content || "No content available"}
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Message ID: {log.messageId}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground">No message logs found</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <Card>
            <CardContent className="py-16 text-center">
              <MessageSquare className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No Server Selected
              </h3>
              <p className="text-sm text-muted-foreground">
                Select a server above to view its logs.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
