import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, Home, Plus, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import ServerSelector from "@/components/server-selector";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Settings() {
  const [selectedServerId, setSelectedServerId] = useState<string>("");
  const [newCommandName, setNewCommandName] = useState("");
  const [newCommandResponse, setNewCommandResponse] = useState("");
  const [newCommandDescription, setNewCommandDescription] = useState("");
  const { toast } = useToast();

  const { data: serverConfig, isLoading } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "config"],
    enabled: !!selectedServerId,
  });

  const { data: customCommands } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "commands"],
    enabled: !!selectedServerId,
  });

  const saveConfigMutation = useMutation({
    mutationFn: async (config: any) => {
      return apiRequest("POST", `/api/servers/${selectedServerId}/config`, config);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers", selectedServerId, "config"] });
      toast({ title: "Settings saved successfully!" });
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const createCommandMutation = useMutation({
    mutationFn: async (command: any) => {
      return apiRequest("POST", `/api/servers/${selectedServerId}/commands`, command);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers", selectedServerId, "commands"] });
      setNewCommandName("");
      setNewCommandResponse("");
      setNewCommandDescription("");
      toast({ title: "Custom command created!" });
    },
    onError: () => {
      toast({ title: "Failed to create command", variant: "destructive" });
    },
  });

  const deleteCommandMutation = useMutation({
    mutationFn: async (commandId: string) => {
      return apiRequest("DELETE", `/api/commands/${commandId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers", selectedServerId, "commands"] });
      toast({ title: "Command deleted!" });
    },
    onError: () => {
      toast({ title: "Failed to delete command", variant: "destructive" });
    },
  });

  const handleSaveConfig = (formData: FormData) => {
    const config = {
      name: formData.get("serverName") as string,
      welcomeChannelId: formData.get("welcomeChannelId") as string,
      welcomeMessage: formData.get("welcomeMessage") as string,
      goodbyeMessage: formData.get("goodbyeMessage") as string,
      autoRoleId: formData.get("autoRoleId") as string,
      moderationLogChannelId: formData.get("moderationLogChannelId") as string,
      announcementChannelId: formData.get("announcementChannelId") as string,
      ticketCategoryId: formData.get("ticketCategoryId") as string,
      moderatorRoleIds: (formData.get("moderatorRoleIds") as string).split(",").map(id => id.trim()).filter(Boolean),
      adminRoleIds: (formData.get("adminRoleIds") as string).split(",").map(id => id.trim()).filter(Boolean),
      enableSpamProtection: formData.get("enableSpamProtection") === "on",
      maxMessagesPerMinute: parseInt(formData.get("maxMessagesPerMinute") as string) || 10,
    };

    saveConfigMutation.mutate(config);
  };

  const handleCreateCommand = () => {
    if (!newCommandName || !newCommandResponse) {
      toast({ title: "Command name and response are required", variant: "destructive" });
      return;
    }

    createCommandMutation.mutate({
      name: newCommandName,
      description: newCommandDescription,
      response: newCommandResponse,
      createdBy: "web-dashboard", // Placeholder since we don't have user auth
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <SettingsIcon className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Bot Settings
              </h1>
            </div>
            <nav className="flex space-x-4">
              <Link href="/">
                <Button variant="ghost">
                  <Home className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
              <Link href="/logs">
                <Button variant="ghost">Logs</Button>
              </Link>
              <Link href="/settings">
                <Button variant="ghost" className="text-blue-600">
                  Settings
                </Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Server Selector */}
        <div className="mb-8">
          <ServerSelector onServerSelect={setSelectedServerId} />
        </div>

        {selectedServerId ? (
          <Tabs defaultValue="general" className="space-y-4">
            <TabsList>
              <TabsTrigger value="general">General Settings</TabsTrigger>
              <TabsTrigger value="moderation">Moderation</TabsTrigger>
              <TabsTrigger value="commands">Custom Commands</TabsTrigger>
              <TabsTrigger value="channels">Channels</TabsTrigger>
            </TabsList>

            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Server Configuration</CardTitle>
                  <CardDescription>
                    Basic server settings and welcome/goodbye messages
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoading ? (
                    <div className="space-y-4">
                      {[...Array(6)].map((_, i) => (
                        <div key={i} className="h-12 bg-gray-200 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : (
                    <form action={handleSaveConfig} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="serverName">Server Name</Label>
                          <Input
                            id="serverName"
                            name="serverName"
                            defaultValue={serverConfig?.name || ""}
                            placeholder="Server name"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="welcomeChannelId">Welcome Channel ID</Label>
                          <Input
                            id="welcomeChannelId"
                            name="welcomeChannelId"
                            defaultValue={serverConfig?.welcomeChannelId || ""}
                            placeholder="Channel ID for welcome messages"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="welcomeMessage">Welcome Message</Label>
                        <Textarea
                          id="welcomeMessage"
                          name="welcomeMessage"
                          defaultValue={serverConfig?.welcomeMessage || ""}
                          placeholder="Welcome message (use {user}, {username}, {server}, {membercount})"
                          rows={3}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="goodbyeMessage">Goodbye Message</Label>
                        <Textarea
                          id="goodbyeMessage"
                          name="goodbyeMessage"
                          defaultValue={serverConfig?.goodbyeMessage || ""}
                          placeholder="Goodbye message (use {user}, {username}, {server}, {membercount})"
                          rows={3}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="autoRoleId">Auto-Role ID</Label>
                        <Input
                          id="autoRoleId"
                          name="autoRoleId"
                          defaultValue={serverConfig?.autoRoleId || ""}
                          placeholder="Role ID to assign to new members"
                        />
                      </div>

                      <Button type="submit" disabled={saveConfigMutation.isPending}>
                        {saveConfigMutation.isPending ? "Saving..." : "Save Settings"}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="moderation" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Moderation Settings</CardTitle>
                  <CardDescription>
                    Configure moderation roles and spam protection
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form action={handleSaveConfig} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="moderatorRoleIds">Moderator Role IDs</Label>
                        <Input
                          id="moderatorRoleIds"
                          name="moderatorRoleIds"
                          defaultValue={serverConfig?.moderatorRoleIds?.join(", ") || ""}
                          placeholder="Comma-separated role IDs"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="adminRoleIds">Admin Role IDs</Label>
                        <Input
                          id="adminRoleIds"
                          name="adminRoleIds"
                          defaultValue={serverConfig?.adminRoleIds?.join(", ") || ""}
                          placeholder="Comma-separated role IDs"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Spam Protection</Label>
                        <p className="text-sm text-muted-foreground">
                          Enable automatic spam detection and timeouts
                        </p>
                      </div>
                      <Switch
                        name="enableSpamProtection"
                        defaultChecked={serverConfig?.enableSpamProtection || false}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="maxMessagesPerMinute">Max Messages Per Minute</Label>
                      <Input
                        id="maxMessagesPerMinute"
                        name="maxMessagesPerMinute"
                        type="number"
                        defaultValue={serverConfig?.maxMessagesPerMinute || 10}
                        placeholder="Maximum messages allowed per minute"
                      />
                    </div>

                    <input type="hidden" name="serverName" value={serverConfig?.name || ""} />
                    <input type="hidden" name="welcomeChannelId" value={serverConfig?.welcomeChannelId || ""} />
                    <input type="hidden" name="welcomeMessage" value={serverConfig?.welcomeMessage || ""} />
                    <input type="hidden" name="goodbyeMessage" value={serverConfig?.goodbyeMessage || ""} />
                    <input type="hidden" name="autoRoleId" value={serverConfig?.autoRoleId || ""} />
                    <input type="hidden" name="moderationLogChannelId" value={serverConfig?.moderationLogChannelId || ""} />
                    <input type="hidden" name="announcementChannelId" value={serverConfig?.announcementChannelId || ""} />
                    <input type="hidden" name="ticketCategoryId" value={serverConfig?.ticketCategoryId || ""} />

                    <Button type="submit" disabled={saveConfigMutation.isPending}>
                      {saveConfigMutation.isPending ? "Saving..." : "Save Settings"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="commands" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Custom Commands</CardTitle>
                  <CardDescription>
                    Create and manage custom bot commands for your server
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Create new command */}
                  <div className="border rounded-lg p-4 space-y-4">
                    <h4 className="font-medium">Create New Command</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="commandName">Command Name</Label>
                        <Input
                          id="commandName"
                          value={newCommandName}
                          onChange={(e) => setNewCommandName(e.target.value)}
                          placeholder="Command name (without !)"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="commandDescription">Description</Label>
                        <Input
                          id="commandDescription"
                          value={newCommandDescription}
                          onChange={(e) => setNewCommandDescription(e.target.value)}
                          placeholder="What does this command do?"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="commandResponse">Response</Label>
                      <Textarea
                        id="commandResponse"
                        value={newCommandResponse}
                        onChange={(e) => setNewCommandResponse(e.target.value)}
                        placeholder="What should the bot respond with?"
                        rows={3}
                      />
                    </div>
                    <Button 
                      onClick={handleCreateCommand}
                      disabled={createCommandMutation.isPending}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      {createCommandMutation.isPending ? "Creating..." : "Create Command"}
                    </Button>
                  </div>

                  {/* Existing commands */}
                  <div className="space-y-3">
                    <h4 className="font-medium">Existing Commands</h4>
                    {customCommands && customCommands.length > 0 ? (
                      customCommands.map((command: any) => (
                        <div key={command.id} className="border rounded-lg p-4 space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="space-y-1">
                              <h5 className="font-medium">!{command.name}</h5>
                              {command.description && (
                                <p className="text-sm text-muted-foreground">{command.description}</p>
                              )}
                            </div>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => deleteCommandMutation.mutate(command.id)}
                              disabled={deleteCommandMutation.isPending}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 rounded p-3">
                            <p className="text-sm font-mono">{command.response}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-muted-foreground">No custom commands created yet.</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="channels" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Channel Configuration</CardTitle>
                  <CardDescription>
                    Configure channels for logs, announcements, and tickets
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form action={handleSaveConfig} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="moderationLogChannelId">Moderation Log Channel</Label>
                        <Input
                          id="moderationLogChannelId"
                          name="moderationLogChannelId"
                          defaultValue={serverConfig?.moderationLogChannelId || ""}
                          placeholder="Channel ID for moderation logs"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="announcementChannelId">Announcement Channel</Label>
                        <Input
                          id="announcementChannelId"
                          name="announcementChannelId"
                          defaultValue={serverConfig?.announcementChannelId || ""}
                          placeholder="Channel ID for announcements"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="ticketCategoryId">Ticket Category ID</Label>
                      <Input
                        id="ticketCategoryId"
                        name="ticketCategoryId"
                        defaultValue={serverConfig?.ticketCategoryId || ""}
                        placeholder="Category ID for support tickets"
                      />
                    </div>

                    {/* Hidden fields to preserve other settings */}
                    <input type="hidden" name="serverName" value={serverConfig?.name || ""} />
                    <input type="hidden" name="welcomeChannelId" value={serverConfig?.welcomeChannelId || ""} />
                    <input type="hidden" name="welcomeMessage" value={serverConfig?.welcomeMessage || ""} />
                    <input type="hidden" name="goodbyeMessage" value={serverConfig?.goodbyeMessage || ""} />
                    <input type="hidden" name="autoRoleId" value={serverConfig?.autoRoleId || ""} />
                    <input type="hidden" name="moderatorRoleIds" value={serverConfig?.moderatorRoleIds?.join(", ") || ""} />
                    <input type="hidden" name="adminRoleIds" value={serverConfig?.adminRoleIds?.join(", ") || ""} />
                    <input type="hidden" name="enableSpamProtection" value={serverConfig?.enableSpamProtection ? "on" : "off"} />
                    <input type="hidden" name="maxMessagesPerMinute" value={serverConfig?.maxMessagesPerMinute || "10"} />

                    <Button type="submit" disabled={saveConfigMutation.isPending}>
                      {saveConfigMutation.isPending ? "Saving..." : "Save Settings"}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <Card>
            <CardContent className="py-16 text-center">
              <SettingsIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No Server Selected
              </h3>
              <p className="text-sm text-muted-foreground">
                Select a server above to configure its settings.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
