import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Activity, Users, Shield, MessageSquare, Ticket, Settings } from "lucide-react";
import { Link } from "wouter";
import BotStatus from "@/components/bot-status";
import ServerSelector from "@/components/server-selector";
import { useState } from "react";

export default function Dashboard() {
  const [selectedServerId, setSelectedServerId] = useState<string>("");

  const { data: botStatus } = useQuery({
    queryKey: ["/api/bot/status"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const { data: moderationLogs, isLoading: logsLoading } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "logs/moderation"],
    enabled: !!selectedServerId,
  });

  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/servers", selectedServerId, "tickets"],
    enabled: !!selectedServerId,
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                Discord Mod Bot Dashboard
              </h1>
            </div>
            <nav className="flex space-x-4">
              <Link href="/">
                <Button variant="ghost" className="text-blue-600">
                  Dashboard
                </Button>
              </Link>
              <Link href="/logs">
                <Button variant="ghost">Logs</Button>
              </Link>
              <Link href="/settings">
                <Button variant="ghost">Settings</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Bot Status */}
        <div className="mb-8">
          <BotStatus status={botStatus} />
        </div>

        {/* Server Selector */}
        <div className="mb-8">
          <ServerSelector onServerSelect={setSelectedServerId} />
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Bot Status</CardTitle>
              <Activity className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {botStatus?.online ? (
                  <Badge variant="default" className="bg-green-500">
                    Online
                  </Badge>
                ) : (
                  <Badge variant="destructive">Offline</Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Uptime: {botStatus?.uptime ? Math.floor(botStatus.uptime / 60000) : 0}m
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Servers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{botStatus?.serverCount || 0}</div>
              <p className="text-xs text-muted-foreground">Connected servers</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Recent Actions</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {moderationLogs?.length || 0}
              </div>
              <p className="text-xs text-muted-foreground">Moderation actions today</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Open Tickets</CardTitle>
              <Ticket className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {tickets?.filter(t => t.status === "open").length || 0}
              </div>
              <p className="text-xs text-muted-foreground">Pending support tickets</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        {selectedServerId ? (
          <Tabs defaultValue="recent" className="space-y-4">
            <TabsList>
              <TabsTrigger value="recent">Recent Activity</TabsTrigger>
              <TabsTrigger value="tickets">Support Tickets</TabsTrigger>
              <TabsTrigger value="commands">Bot Commands</TabsTrigger>
              <TabsTrigger value="overview">Server Overview</TabsTrigger>
            </TabsList>

            <TabsContent value="recent" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Moderation Actions</CardTitle>
                  <CardDescription>
                    Latest moderation actions taken in this server
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {logsLoading ? (
                    <div className="space-y-3">
                      {[...Array(5)].map((_, i) => (
                        <div key={i} className="h-4 bg-gray-200 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : moderationLogs && moderationLogs.length > 0 ? (
                    <div className="space-y-3">
                      {moderationLogs.slice(0, 10).map((log: any) => (
                        <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <Badge variant={
                              log.action === "ban" ? "destructive" :
                              log.action === "kick" ? "secondary" :
                              log.action === "warn" ? "outline" : "default"
                            }>
                              {log.action}
                            </Badge>
                            <span className="text-sm">
                              User ID: {log.targetUserId}
                            </span>
                            <span className="text-sm text-muted-foreground">
                              Reason: {log.reason || "No reason provided"}
                            </span>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {new Date(log.createdAt).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No recent moderation actions</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="tickets" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Support Tickets</CardTitle>
                  <CardDescription>
                    Current support tickets in this server
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {ticketsLoading ? (
                    <div className="space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
                      ))}
                    </div>
                  ) : tickets && tickets.length > 0 ? (
                    <div className="space-y-3">
                      {tickets.map((ticket: any) => (
                        <div key={ticket.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <h4 className="font-medium">{ticket.subject}</h4>
                              <Badge variant={ticket.status === "open" ? "default" : "secondary"}>
                                {ticket.status}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              User ID: {ticket.userId} • Channel: #{ticket.channelId}
                            </p>
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {new Date(ticket.createdAt).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No support tickets found</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="commands" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Available Bot Commands</CardTitle>
                  <CardDescription>
                    All commands available for your Discord moderation bot
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* Prefix Commands */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-sm text-purple-600 dark:text-purple-400">Prefix Commands (!)</h4>
                      <div className="space-y-2">
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!kick @user [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Remove a user from the server</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!ban @user [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Permanently ban a user</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!warn @user [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Issue a warning to a user</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!mute @user [time] [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Timeout a user (time in minutes)</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!purge [amount]</code>
                          <p className="text-xs text-muted-foreground mt-1">Delete multiple messages (1-100)</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!ping</code>
                          <p className="text-xs text-muted-foreground mt-1">Check bot latency and status</p>
                        </div>
                      </div>
                    </div>

                    {/* Slash Commands */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-sm text-blue-600 dark:text-blue-400">Slash Commands (/)</h4>
                      <div className="space-y-2">
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/kick [user] [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Advanced kick with case tracking</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/ban [user] [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Advanced ban with case tracking</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/warn [user] [reason]</code>
                          <p className="text-xs text-muted-foreground mt-1">Advanced warning system</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/warnings [user]</code>
                          <p className="text-xs text-muted-foreground mt-1">View user warning history</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/case [number]</code>
                          <p className="text-xs text-muted-foreground mt-1">Look up moderation case details</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/dm [user] [message]</code>
                          <p className="text-xs text-muted-foreground mt-1">Send DM with spam options</p>
                        </div>
                      </div>
                    </div>

                    {/* Fun & Utility Commands */}
                    <div className="space-y-3">
                      <h4 className="font-semibold text-sm text-green-600 dark:text-green-400">Fun & Utility</h4>
                      <div className="space-y-2">
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!help</code>
                          <p className="text-xs text-muted-foreground mt-1">Show available commands</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!say [message]</code>
                          <p className="text-xs text-muted-foreground mt-1">Make the bot say something</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">!dm @user [message]</code>
                          <p className="text-xs text-muted-foreground mt-1">Send a quick DM to a user</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/uptime</code>
                          <p className="text-xs text-muted-foreground mt-1">Check how long bot has been running</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/clean [amount] [user]</code>
                          <p className="text-xs text-muted-foreground mt-1">Advanced message cleanup</p>
                        </div>
                        <div className="p-2 border rounded">
                          <code className="text-sm font-mono">/slowmode [seconds]</code>
                          <p className="text-xs text-muted-foreground mt-1">Set channel slowmode delay</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg border border-purple-200 dark:border-purple-800">
                      <h4 className="font-medium text-purple-900 dark:text-purple-100 mb-2">💬 Prefix Commands (!)</h4>
                      <p className="text-sm text-purple-700 dark:text-purple-300">
                        Quick commands you can type in chat. Use <code>!help</code> to see all available commands.
                      </p>
                      <ul className="text-sm text-purple-700 dark:text-purple-300 mt-2 space-y-1">
                        <li>• Fast execution in chat</li>
                        <li>• Basic moderation features</li>
                        <li>• Fun and utility commands</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                      <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">⚡ Anti-Spam Protection</h4>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        Automatic spam detection with progressive enforcement:
                      </p>
                      <ul className="text-sm text-blue-700 dark:text-blue-300 mt-2 space-y-1">
                        <li>• Detects rapid message sending</li>
                        <li>• Progressive timeouts for repeat offenders</li>
                        <li>• Automatic message deletion</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="overview" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Server Overview</CardTitle>
                  <CardDescription>
                    General information about the selected server
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-medium">Server Configuration</h4>
                      <p className="text-sm text-muted-foreground">
                        Configure bot settings, welcome messages, and moderation roles
                      </p>
                      <Link href="/settings">
                        <Button size="sm">
                          <Settings className="h-4 w-4 mr-2" />
                          Configure Server
                        </Button>
                      </Link>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium">View Logs</h4>
                      <p className="text-sm text-muted-foreground">
                        View detailed moderation and message logs
                      </p>
                      <Link href="/logs">
                        <Button size="sm" variant="outline">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          View All Logs
                        </Button>
                      </Link>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        ) : (
          <Card>
            <CardContent className="py-16 text-center">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium text-muted-foreground mb-2">
                No Server Selected
              </h3>
              <p className="text-sm text-muted-foreground">
                Select a server above to view its dashboard and manage bot settings.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
